/**
 * @license @product.name@ JS v@product.version@ (@product.date@)
 * Sonification module
 *
 * (c) 2012-2018 Øystein Moseng
 *
 * License: www.highcharts.com/license
 */

'use strict';

import '../../modules/sonification/sonification.js';
