/**
 * @license @product.name@ JS v@product.version@ (@product.date@)
 * Client side exporting module
 *
 * (c) 2015-2018 Torstein Honsi / Oystein Moseng
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../modules/offline-exporting.src.js';
