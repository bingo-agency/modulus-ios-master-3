/**
 * @license  @product.name@ JS v@product.version@ (@product.date@)
 *
 * Indicator series type for Highstock
 *
 * (c) 2010-2018 Rafal Sebestjanski
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../indicators/tema.src.js';
