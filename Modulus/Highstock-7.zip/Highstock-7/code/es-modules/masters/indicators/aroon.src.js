/**
 * @license  @product.name@ JS v@product.version@ (@product.date@)
 *
 * Indicator series type for Highstock
 *
 * (c) 2010-2018 Wojciech Chmiel
 *
 * License: www.highcharts.com/license
 */
'use strict';
import '../../indicators/aroon.src.js';
